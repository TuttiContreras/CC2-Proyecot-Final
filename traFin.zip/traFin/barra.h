#ifndef BARRA_H_INCLUDE
#define BARRA_H_INCLUDE

#include <SFML/Graphics.hpp>
#include "confi.h"
#include <sstream>
#include <iostream>


class BARRA{
public:
  BARRA();
  void add_puntuacion();
  void dis_salud();
  void dis_vida();
}; 

BARRA::BARRA() {}

void BARRA::add_puntuacion(){
  puntuacion++;
}

void BARRA::dis_vida(){  
  if(salud=0){
    vida--;
    salud=3;
  }
}

void BARRA::dis_salud(){
  salud--;
}

#endif 