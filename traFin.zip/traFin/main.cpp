#include "menu.h"

int main(){
	Menu mo;
	mo.draw();
}




