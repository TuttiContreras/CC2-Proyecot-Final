#ifndef OBJETOS_H_INCLUDE
#define OBJETOS_H_INCLUDE

#include <iostream>
#include <time.h>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

//#include "confi.h"

class OBJETO : public sf::Sprite{ 
public:
	virtual void movimiento(){};
	virtual void delete_ob()=0;
	virtual int X()=0;
	virtual int Y()=0;	
};

class OBJETO_PLAYER : public OBJETO{
public:
    OBJETO_PLAYER();
    void movimiento();
    void delete_ob();
    int X(){return x;}
    int Y(){return y;}

private:
	int x,y;
    sf::Texture texture_nave;
    sf::Vector2f speed; //constructor Construct the vector from its coordinates. 
};


OBJETO_PLAYER::OBJETO_PLAYER(){
	this->x=100; this->y=365;
	texture_nave.loadFromFile("image/betho.png");
	this->setTexture(texture_nave);
	this->setPosition(x,y);
	this->speed.x = 300.0f;
	this->speed.y = 300.0f;
}

void OBJETO_PLAYER::movimiento(){

	if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) && ( x < (WIDTH -250) )) x  += 120;
    if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) && ( x > 150 )) x  -= 120;
    //if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))  return false;
    this->setPosition(x, y);
}

void  OBJETO_PLAYER::delete_ob(){}

////////////////////////////////////////////////////////////////////////////////


class OBJETO_PLAYER2 : public OBJETO{
public:
    OBJETO_PLAYER2();
    void movimiento();
    void delete_ob();
    void arma();
    int X(){return x;}
    int Y(){return y;}

private:
	int x,y;
    sf::Texture texture_nave2;
    sf::Vector2f speed; //constructor Construct the vector from its coordinates. 
};


OBJETO_PLAYER2::OBJETO_PLAYER2(){
	this->x=5; this->y=70;
	texture_nave2.loadFromFile("image/bethoi.png");
	this->setTexture(texture_nave2);
	this->setPosition(x,y);
	this->speed.x = 300.0f;
	this->speed.y = 300.0f;
}

void OBJETO_PLAYER2::movimiento(){

	if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) && ( y >  70)) y  -= 50;
    if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) && ( y < 320 )) y  +=50;
    this->setPosition(x, y);
}

void OBJETO_PLAYER2::arma(){//OBJETO_A& A,OBJETO_PLAYER& B, OBJETO_B& C){
	if ((sf::Keyboard::isKeyPressed(sf::Keyboard::Return))){
		int a=rand()%4;
		int p[]={460,220,340,100};
		int x1=p[a];
		this->move(x1,0);
	}
}



void  OBJETO_PLAYER2::delete_ob(){}


////////////////////////////////////////////////////////////////////////////////

class OBJETO_A : public OBJETO {

public:
    OBJETO_A();
    ~OBJETO_A();
    int X(){return x1;}
    int Y(){return y1;}
    void movimiento();
    void delete_ob(){}
    float getSpeedX() const;

private:
	int x1,y1;
    sf::Texture texture_obj1;
    sf::Vector2f speed;
};


OBJETO_A::OBJETO_A(){
	this->x1=100; this->y1=70;
	texture_obj1.loadFromFile("image/moca.png");
	this->setTexture(texture_obj1);
	int a=rand()%4;
	int p[]={460,220,340,100};
	this->x1=p[a]; 
	this->setPosition(x1, y1);
	this->speed.x = 200.0f;
	this->speed.y = 200.0f;
}

OBJETO_A::~OBJETO_A() {}//delete texture_obj1;}

void OBJETO_A::movimiento(){
	y1+=2;
	this->setPosition(x1, y1);
	if (y1 >= 360 ) { 
		int a=rand()%4;
		int p[]={460,220,340,100};
		this->x1=p[a]; 
		this->y1=75; 
		this->setPosition(x1, y1);
	}
	//this->move(0,2);
	//this->move(240,75);
}

float OBJETO_A::getSpeedX() const{return speed.x;}




class OBJETO_B : public OBJETO {

public:
    OBJETO_B();
    ~OBJETO_B();
    int X(){return x1;}
    int Y(){return y1;}
    void movimiento();
    void delete_ob(){}
    float getSpeedX() const;

private:
	int x1,y1;
    sf::Texture texture_obj1;
    sf::Vector2f speed;
};


OBJETO_B::OBJETO_B(){
	this->x1=100; this->y1=70;
	texture_obj1.loadFromFile("image/mocar.png");
	this->setTexture(texture_obj1);
	int a=rand()%4;
	int p[]={460,220,340,100};
	this->x1=p[a]; 
	this->setPosition(x1, y1);
	this->speed.x = 100.0f;
	this->speed.y = 100.0f;
}

OBJETO_B::~OBJETO_B() {}//delete texture_obj1;}

void OBJETO_B::movimiento(){
	y1+=1;
	this->setPosition(x1, y1);
	if (y1 >= 360 ) { 
		int a=rand()%4;
		int p[]={460,220,340,100};
		this->x1=p[a]; 
		this->y1=75; 
		this->setPosition(x1, y1);
	}
	//this->move(0,2);
	//this->move(240,75);
}

float OBJETO_B::getSpeedX() const{return speed.x;}

#endif	
