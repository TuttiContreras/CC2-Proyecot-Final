#ifndef MENU_H_INCLUDE
#define MENU_H_INCLUDE

#include "confi.h"
#include "mapa.h"
#include "opciones.h"
#include <SFML/Graphics.hpp>

#define MAX_OPCIONES  3

using namespace sf;

class Menu
{
public:
	Menu();
	~Menu();

	void draw();
	void MoveUp();
	void MoveDown();
	int GetPressedItem() { return selectedItemIndex; }

private:
	int selectedItemIndex;
	sf::Font font;
	sf::Texture texture_fon_ini;
	sf::Sprite fon_ini;
	sf::Text menu[MAX_OPCIONES];
	MAPA ma; OPCIONES p;
	SoundBuffer buffer; Sound sound;

};

Menu::Menu(){
	texture_fon_ini.loadFromFile("image/fondo_ini.jpg");
	fon_ini.setTexture(texture_fon_ini);
	font.loadFromFile("image/font.ttf");
	buffer.loadFromFile("image/musicc.ogg");
  	sound.setBuffer(buffer);

	menu[0].setString("JUGAR");
	menu[0].setFont(font);
	menu[0].setCharacterSize(25);
	menu[0].setFillColor(sf::Color::Red);
	menu[0].setPosition(300,300);

	menu[1].setFont(font);
	menu[1].setCharacterSize(25);
	menu[1].setFillColor(sf::Color::Black);
	menu[1].setString("OPCIONES");
	menu[1].setPosition(300,340);

	menu[2].setFont(font);
	menu[2].setCharacterSize(25);
	menu[2].setFillColor(sf::Color::Black);
	menu[2].setString("SALIR");
	menu[2].setPosition(300,380);

	selectedItemIndex = 0;
}

Menu::~Menu(){}


void Menu::MoveUp()
{
	if (selectedItemIndex - 1 >= 0)
	{
		menu[selectedItemIndex].setFillColor(sf::Color::Black);
		selectedItemIndex--;
		menu[selectedItemIndex].setCharacterSize(35);
		menu[selectedItemIndex].setFillColor(sf::Color::Red);
		menu[selectedItemIndex+1].setCharacterSize(25);

	}
}

void Menu::MoveDown()
{
	if (selectedItemIndex + 1 < MAX_OPCIONES)
	{
		menu[selectedItemIndex].setFillColor(sf::Color::Black);
		
		selectedItemIndex++;
		menu[selectedItemIndex].setCharacterSize(35);
		menu[selectedItemIndex].setFillColor(sf::Color::Red);
		menu[selectedItemIndex-1].setCharacterSize(25);
	}
}


void Menu::draw(){
	window_play.create(sf::VideoMode(WIDTH, HEIGHT, BPP), "PANTALLA DE INICIO", sf::Style::Close);
	window_play.setVerticalSyncEnabled(true);
	sound.play();
	while (window_play.isOpen()){
		sf::Event event1;
		while (window_play.pollEvent(event1)){
			if (event1.type == sf::Event::Closed)
				window_play.close();
			//if ((event.type == sf::Event::keyPressed) && (event.key.code == sf::Key::Escape))
            //	window.close();
            //window.clear();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up))MoveUp();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down))MoveDown();
            
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 0){window_play.clear(sf::Color(180, 200, 255));ma.compilar(); }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 1){p.draw();}
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 2){ window_play.close();}
            sound.setLoop(true);
		}
	window_play.draw(fon_ini);
	for (int i = 0; i < MAX_OPCIONES; i++)
		window_play.draw(menu[i]);
	window_play.display();
	}
}

#endif 
