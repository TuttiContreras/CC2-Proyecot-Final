#ifndef JUEGO_H_INCLUDE
#define JUEGO_H_INCLUDE

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include "objetos.h"
#include "confi.h"

using namespace std;
using namespace sf;

class Juego{
private:
	friend bool operator-(OBJETO& A,OBJETO& B);
	//OBJETO& obj_a;
	//OBJETO& obj_b;
	int puntuacion,salud,vida;
public:
	Juego();
	int p(){return puntuacion;}
	int v(){return vida;}
	int s(){return salud;}
	void dis_salud(OBJETO_A& A,OBJETO_PLAYER& B, OBJETO_B& C);
	void add_pun(OBJETO_A& A,OBJETO_PLAYER& B);
	
};
Juego::Juego(){
	this->puntuacion=0;
	this->vida=3;
	this->salud=3;
}//int Puntuacion, int Vida, int Salud):Puntuacion(puntuacion),Vida(vida),Salud(salud){}

void Juego::add_pun(OBJETO_A& A,OBJETO_PLAYER& B){
	if( abs(A.X() - B.X())<10 && A.Y() > 357 ) {
		this->puntuacion++;
		//texture_nave.loadFromFile("image/betho.png");
		//this->setTexture(texture_nave);
	}
}
void Juego::dis_salud(OBJETO_A& A,OBJETO_PLAYER& B, OBJETO_B& C){
	if( A.X() !=  B.X() && A.Y() > 357 ){this->salud--;}
	if (this->salud==0){this->vida-- ; this->salud=3;}
	if( abs(C.X() -  B.X())<10 && C.Y() > 358 ){this->salud--;}
	if (this->salud==0){this->vida-- ; this->salud=3;}
}

bool operator-(OBJETO& A,OBJETO& B){
	if(abs(A.X()- B.X() )<100 ){ return true; } return false;
}



#endif 