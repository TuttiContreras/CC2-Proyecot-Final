#ifndef PUNTUACIONES_H_INCLUDE
#define PUNTUACIONES_H_INCLUDE

#include <iostream>

using namespace std;

class nodo{
public:
    int dato;
    nodo *sig;
public:
    nodo(int &dato){
        this->dato=dato;
        this->sig=NULL;
    }
    int getdato(){
        return dato;
    }
};

class listaEnsalada{
    public:
    nodo *inicio;
    nodo *fin;

    public:
    listaEnsalada(){
        this->inicio=NULL;
        this->fin=NULL;}

    bool vacio(){return (inicio==NULL);}
    
    void insertarfinal(int dato2){
    nodo *nuevo= new nodo(dato2);
    if (vacio()) fin=inicio=nuevo;
    else{
        fin->sig = nuevo;
        fin = nuevo;}
    }

    void eliminarfin(){
        if (vacio())cout<<"La lista esta vacia\n";
        else if (inicio==fin) inicio=fin=NULL;
        else{
            nodo *auxiliar = inicio;
            while(auxiliar->sig!=fin){
                    auxiliar=auxiliar->sig;
            }
            fin=auxiliar;
            fin->sig=NULL;
            delete auxiliar;
        }
    }

    bool esta(int _X){
        if (vacio()) {
            return false;}
        while (inicio!=NULL) {
            if (inicio->dato == _X) {
                return true;
            }
            inicio=inicio->sig;
        }
        return false;
    }

    void busquedaPorDato(int dato2){
        int cont = 0;int c=0;
        if (vacio()) {
            cout<<"La lista esta vacia "<<endl;}
        else{
            nodo *auxiliar=inicio;
            while (auxiliar!=NULL) {
            if (auxiliar->dato == dato2) {
                auxiliar=auxiliar->sig;
                cont++;
                c++;
                cout<<dato2<<" Esta en la pos "<<cont<<" ";}
            else{
            auxiliar=auxiliar->sig;
            cont++;}
            }
            cout<<endl;
        }
        if (c == 0) {
            cout << "No existe el dato " << endl;
        }
    }

    void busquedaPorPos(int dato2){
        int cont = 0;int c=0;
        if (vacio()) {
            cout<<"La lista esta vacia "<<endl;}
        else{
            nodo *auxiliar=inicio;
            while (auxiliar!=NULL) {
                if (cont == (dato2-1)) {
                    cont++;
                    c++;
                    cout<<auxiliar->dato<<" Esta en la pos "<<cont<<" ";
                    break;}
                else{
                auxiliar=auxiliar->sig;
                cont++;}
                }
                cout<<endl;
        }
        if (c == 0) {
            cout << "No existe el dato " << endl;
        }
    }

    void mostrar(){
    nodo *auxiliar;
    if(inicio == NULL) cout<<"\nLa lista esta vacia\n";
    auxiliar = inicio;
    while(auxiliar != NULL)
        {
         cout<<auxiliar->getdato()<<" ";
        auxiliar = auxiliar->sig;
        }
    cout<<endl;
    }
};

#endif 