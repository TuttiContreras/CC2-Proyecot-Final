#ifndef CONFIG_H_INCLUDE
#define CONFIG_H_INCLUDE
#include <SFML/Graphics.hpp>

sf::RenderWindow window_play;

static const unsigned int WIDTH = 700;
static const unsigned int HEIGHT = 550;
static const unsigned int BPP = 32;

//unsigned int puntuacion = 1;
//unsigned int vida = 3;
//unsigned int salud = 3;

//puntuacion= &Puntuacion;
//vida = &Vida;
//salud = &Salud;

// coordenadas de payer1;
//int x = 100;
//int y = 400;

//int c=rand()%4;
//int p[]={460,220,340,100};

//coordenadas de objetos
//int x1 = p[c];
//int y1 = 70;

#endif // CONFIG_H_INCLUDE
