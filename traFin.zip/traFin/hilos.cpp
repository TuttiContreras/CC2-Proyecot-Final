//#include "conio.h" //es para el getch()
#include <thread> //crear hilo
#include <iostream> //flujo d esalida
#include <fstream> //manejo de archivos
#include <stdio.h>
#include <sstream>
#include <string>

using namespace std;
//using namespace sf;


void funcion(){
	std::ofstream outfile("Nombre del archivo");
	outfile<<"este archivo va dentro del archivo"<<std::endl;
	outfile::close();
}

int main(){
	std::thread nombre(funcion);
	nombre.join();
	//getch();
}
