#ifndef OPCIONES_H_INCLUDE
#define OPCIONES_H_INCLUDE

#include "confi.h"
#include "mapa.h"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Text.hpp>

#define MAX_OPCIONES  3

using namespace sf;

class OPCIONES
{
public:
	OPCIONES();
	~OPCIONES();

	void draw();
	void MoveUp();
	void MoveDown();
	int GetPressedItem() { return selectedItemIndex; }

private:
	int selectedItemIndex;
	sf::Font font;
	sf::Texture texture_fon_ini;
	sf::Sprite fon_ini;
	sf::Text opciones[MAX_OPCIONES];

};

OPCIONES::OPCIONES()
{
	//window_play.create(sf::VideoMode(WIDTH, HEIGHT, BPP), "PANTALLA DE CONFIGURACIONES", sf::Style::Close);
	//window_play.setVerticalSyncEnabled(true);
	texture_fon_ini.loadFromFile("image/fondo_ini.jpg");
	fon_ini.setTexture(texture_fon_ini);
	font.loadFromFile("image/font.ttf");

	opciones[0].setString("PUNTAJES ALTOS");
	opciones[0].setFont(font);
	opciones[0].setCharacterSize(25);
	opciones[0].setFillColor(sf::Color::Red);
	opciones[0].setPosition(200,300);

	opciones[1].setString("VOLVER");
	opciones[1].setFont(font);
	opciones[1].setCharacterSize(25);
	opciones[1].setFillColor(sf::Color::Black);
	opciones[1].setPosition(250,340);
	
	opciones[2].setString("SALIR");
	opciones[2].setFont(font);
	opciones[2].setCharacterSize(25);
	opciones[2].setFillColor(sf::Color::Black);
	opciones[2].setPosition(275,380);

	selectedItemIndex = 0;
}

OPCIONES::~OPCIONES(){}


void OPCIONES::MoveUp(){
	if (selectedItemIndex - 1 >= 0){
		opciones[selectedItemIndex].setFillColor(sf::Color::Black);
		selectedItemIndex--;
		opciones[selectedItemIndex].setCharacterSize(35);
		opciones[selectedItemIndex].setFillColor(sf::Color::Red);
		opciones[selectedItemIndex+1].setCharacterSize(25);

	}
}

void OPCIONES::MoveDown(){
	if (selectedItemIndex + 1 < MAX_OPCIONES){
		opciones[selectedItemIndex].setFillColor(sf::Color::Black);
		selectedItemIndex++;
		opciones[selectedItemIndex].setCharacterSize(35);
		opciones[selectedItemIndex].setFillColor(sf::Color::Red);
		opciones[selectedItemIndex-1].setCharacterSize(25);
	}
}


void OPCIONES::draw(){
	window_play.create(sf::VideoMode(WIDTH, HEIGHT, BPP), "holi, que decea?", sf::Style::Close);
	window_play.setVerticalSyncEnabled(true);
	while (window_play.isOpen()){
		sf::Event event;
		while (window_play.pollEvent(event)){
			if (event.type == sf::Event::Closed)
				window_play.close();
			//if ((event.type == sf::Event::keyPressed) && (event.key.code == sf::Key::Escape))
            //	window.close();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) MoveUp();
			if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) MoveDown();
            
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 0){ window_play.clear(sf::Color(180, 200, 255)); }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 1){ window_play.clear(sf::Color(180, 200, 255)); }
            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return) && (selectedItemIndex) == 2){ window_play.clear(sf::Color(180, 200, 255)); window_play.close();}
		}
	window_play.draw(fon_ini);
	for (int i = 0; i < MAX_OPCIONES; i++)
		window_play.draw(opciones[i]);
	window_play.display();
	}
}

#endif 
