#ifndef VECTORMUSICA_H_INCLUDE
#define VECTORMUSICA_H_INCLUDE


#include <iostream>
#include <vector>

using namespace std;
template <class T> class Queue;
template<class T> Queue<T> operator+(const Queue<T> &queue1,const Queue<T> &queue2);
template<class T> Queue<T> operator-(const Queue<T> &queue1,const Queue<T> &queue2);

template <class T>

class Queue{
    friend Queue<T> operator+<>(const Queue<T> &queue1,const Queue<T> &queue2);
    friend Queue<T> operator-<>(const Queue<T> &queue1,const Queue<T> &queue2);
	vector<T> vqueue;
	
public:
    Queue(){tam=0;};
	bool Empty(){if(vqueue.size()<=0) return true; else return false;}

	int size(){return vqueue.size();}

	void agregar(const T &x){return vqueue.push_back(x);}

	T First(){return vqueue.front();}

	void eliminar(){vqueue.erase(vqueue.begin());}

	void mostrar(){
		for (int i = 0; i < vqueue.size(); ++i)
			cout<<vqueue[i]<<" ";
		cout<<endl;
	}

	bool esta(T y){
    for (int i = 0; i < vqueue.size(); ++i)
        if (y==vqueue[i])return true;else return false;
    }
};


template<class T>
Queue<T> operator-(const Queue<T> &queue1,const Queue<T> &queue2){
    Queue  <T> tmp=queue1;
    Queue  <T> tmp2=queue2;
//    for (int i = 0; i < queue1.vqueue.size(); ++i){
    for (int i = 0; i < queue1.size(); ++i){
        if (tmp.esta(tmp2.First())){
            tmp.eliminar();
            tmp2.eliminar();}
        else
            tmp2.eliminar();
    }
    return tmp;
}

template<class T>
Queue<T> operator+(const Queue<T> &queue1,const Queue<T> &queue2){
    Queue<T> tmp=queue1;
    Queue<T> tmp2=queue2;
//    for (int i = 0; i < queue2.vqueue.size(); ++i){
    for (int i = 0; i < queue2.size(); ++i){
        if (!tmp.esta(tmp2.First())){
        tmp.agregar(tmp2.First());
        tmp2.eliminar();}
        else
        tmp2.eliminar();
    }
    return tmp;
}

/*
int main(){
	Queue <int> queue1;
	Queue <int> queue2;
//	Queue <int> queue3;
    if(queue1.Empty())
    cout<<"true"<<endl;else
    cout<<"false"<<endl;
    queue1.agregar(2);*/

#endif