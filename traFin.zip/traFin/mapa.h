#ifndef MAPA_H_INCLUDE
#define MAPA_H_INCLUDE

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <sstream>
#include <string>
#include <iostream>
#include "confi.h"
#include "juego.h"
#include "objetos.h"
#include "menu.h"
#include "puntuaciones.h"

using namespace std;
using namespace sf;

class MAPA{
public:
    MAPA();

	void compilar();
  void mov();

private:
 	Clock clock;Time time;
	Texture texture_fon;Sprite fondo;Font font; SoundBuffer buffer; Sound sound;

 	sf::Text text_punt;sf::Text text_vidas;sf::Text text_salud;Text text_game;
 	sf::String cadena1;sf::String cadena2;sf::String cadena3;
	sf::Text num_punt;sf::Text num_vidas;sf::Text num_salud;
	OBJETO_PLAYER j1; OBJETO_PLAYER2 j2; OBJETO_A o1; OBJETO_B O2; Juego j;	listaEnsalada lista;
};

MAPA::MAPA(){
	window_play.create(sf::VideoMode(WIDTH, HEIGHT, BPP), "music pool", sf::Style::Close);
	window_play.setVerticalSyncEnabled(true);
	texture_fon.loadFromFile("image/fondo.jpg");
	fondo.setTexture(texture_fon);
	font.loadFromFile("image/font.otf");
  buffer.loadFromFile("image/musicc.ogg");
  sound.setBuffer(buffer);

  text_punt.setString("PUNTUACION: ");
  text_vidas.setString("VIDAS: ");
  text_salud.setString("SALUD: ");
  text_game.setString("GAME OVER");

  	
  text_punt.setCharacterSize(20);
  text_vidas.setCharacterSize(20);
  text_salud.setCharacterSize(20);
  text_game.setCharacterSize(50);

  text_punt.setFont(font);
  text_vidas.setFont(font);
  text_salud.setFont(font);
  text_game.setFont(font);

  text_punt.setPosition(120, 50);
  text_vidas.setPosition(335,50);
  text_salud.setPosition(500,50);
  text_game.setPosition(335,250);

  num_punt.setCharacterSize(20);
  num_vidas.setCharacterSize(20);
  num_salud.setCharacterSize(20);

  num_punt.setFont(font);
  num_vidas.setFont(font);
  num_salud.setFont(font);

  num_punt.setPosition(250, 50);
  num_vidas.setPosition(400,50);
  num_salud.setPosition(570,50);


  text_punt.setFillColor(sf::Color::Black);
  text_vidas.setFillColor(sf::Color::Black);
  text_salud.setFillColor(sf::Color::Black);

  num_punt.setFillColor(sf::Color::Black);
  num_vidas.setFillColor(sf::Color::Black);
  num_salud.setFillColor(sf::Color::Black);
}

void MAPA::mov(){
  o1.movimiento();
}

void MAPA::compilar()
{
  window_play.create(sf::VideoMode(WIDTH, HEIGHT, BPP), "DIWIDI", sf::Style::Close);
  window_play.setVerticalSyncEnabled(true);
  sf::RectangleShape bar(sf::Vector2f(500.f, 50.f));
  bar.setFillColor(sf::Color(98, 225, 39));
  bar.setPosition(100,40);
  time = clock.restart();
  sound.play();
	while (window_play.isOpen()){
  std::stringstream ja;
  std::stringstream je;
  std::stringstream ji;
  

    ja << j.p();
    je << j.v();
    ji << j.s();

    num_punt.setString(ja.str());
    num_vidas.setString(je.str());
    num_salud.setString(ji.str());
		sf::Event event;
		while (window_play.pollEvent(event)){
			if(event.type == sf::Event::Closed){ window_play.clear( sf::Color(180, 200, 255));window_play.close(); } 
      //if(sf::Keyboard::isKeyPressed(sf::Keyboard::Return)) {window_play.close();}
      if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)){ window_play.clear(sf::Color(180, 200, 255)); window_play.close();} 
      if(j.v()==0){ window_play.close();}
      sound.setLoop(true);
      j1.movimiento();
      j2.movimiento();
      j2.arma();
    

     // if(o1.movimiento(time)=true)o1.movimiento();
      window_play.display();
		}
    if(j.v()==0){ window_play.close();}
    o1.movimiento();
    O2.movimiento();
    j.add_pun(o1,j1);
    j.dis_salud(o1,j1, O2);
    //MAPA objet;
    //sf::Thread thread(&MAPA::mov, &objet);

	window_play.draw(fondo);
	window_play.draw(bar);
  window_play.draw(j1);
	window_play.draw(o1);
  window_play.draw(O2);
  window_play.draw(j2);
		
	window_play.draw(text_punt);
  window_play.draw(text_vidas);
  window_play.draw(text_salud);

  window_play.draw(num_punt);
  window_play.draw(num_vidas);
  window_play.draw(num_salud);

	window_play.display();
	}
}

#endif 
